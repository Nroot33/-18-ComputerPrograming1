import java.util.Scanner;

public class Text {
	String con_vow = null;
	int i = 0;
	int conson, vowel = 0;

	void consonant() {
		while (true) {
			if (con_vow.charAt(i) == 'a' || con_vow.charAt(i) == 'e' || con_vow.charAt(i) == 'i'
					|| con_vow.charAt(i) == 'o' || con_vow.charAt(i) == 'u') {
				conson += 1;
				i++;
			} else {
				vowel += 1;
				i++;
			}

			if (i == con_vow.length())
				break;
		}

		System.out.println("������ ������ " + conson + "���Դϴ�.");
		System.out.println("������ ������ " + vowel + "���Դϴ�.");
	}

	public static void main(String args[]) {
		Text TextTest = new Text();
		Scanner input = new Scanner(System.in);

		System.out.print("���ڿ� �Է�: ");
		TextTest.con_vow = input.nextLine();

		TextTest.consonant();
	}
}