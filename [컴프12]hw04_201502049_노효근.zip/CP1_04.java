import java.util.*;

public class CP1_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Random r = new Random(System.currentTimeMillis());
		 
	        int num1 = r.nextInt(45) + 1;
	        int num2 = 0;
	        int num3 = 0;
	        int num4 = 0;
	        int num5 = 0;
	        int num6 = 0;
	        
	        int temp, count = 1;
	    
	        while(count < 6) {
	            temp = r.nextInt(45) + 1;
	            if(count == 1) {
	                if(num1 != temp) {
	                    num2 = temp; count++;
	                }
	            }else if(count == 2){
	                if(num1 !=temp && num2 !=temp) {
	                    num3 = temp; count++;
	                }
	            }else if(count == 3){
	                if(num1 !=temp && num2 !=temp && num3 !=temp) {
	                    num4 = temp; count++;
	                }
	            }else if(count == 4) {
	                if(num1 !=temp && num2 !=temp && num3 !=temp && num4 !=temp) {
	                    num5 = temp; count++;
	                }
	            }else if(count == 5) {
	                if(num1 !=temp && num2 !=temp && num3 !=temp && num4 !=temp && num5 !=temp) {
	                    num6 = temp; count++;
	                }
	            }
	        }
	 
	        System.out.println("<�ζ� ���� ���α׷�>");
	        System.out.println(num1 + " " + num2 + " " + num3 + " " + num4 + " " + num5 + " " + num6 + " ");
	 
	    }
	}