public class Customer extends Person {
	private int cumstomurNum;
	private int mileage;

	public Customer() {

	}

	public Customer(String name, String address, String phoneNum) {
		super(name, address, phoneNum);
	}
	
	public Customer(String name, String address, String phoneNum, int cumstomurNum, int mileage) {
		super(name, address, phoneNum);
		this.cumstomurNum = cumstomurNum;
		this.mileage = mileage;
	}

	@Override
	public void print() {
		super.print();
		System.out.println("cumstomurNum : " + cumstomurNum);
		System.out.println("mileage : " + mileage);

	}

	public int getCumstomurNum() {
		return cumstomurNum;
	}

	public void setCumstomurNum(int cumstomurNum) {
		this.cumstomurNum = cumstomurNum;
	}

	public int getMileage() {
		return mileage;
	}

	public void setMileage(int mileage) {
		this.mileage = mileage;
	}

}