
public class TestStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student student1 = new Student();
		Student student2 = new Student("John","201502000","computer",2,15);
		
		
		System.out.println("Student");
		student1.print();
		System.out.println(" ");
		System.out.println("Student");
		student2.print();
		System.out.println(" ");
		
		Undergraduate undergraduate  = new Undergraduate("John","201502000","computer",2,15,"Admin");
		
		System.out.println("Undergraduate");
		undergraduate.print();
		System.out.println(" ");
		
		System.out.println("Graduate");
		Graduate Graduate = new Graduate("John","201502000","computer",2,15,"teaching assistant",0.5);
		Graduate.print();
		System.out.println(" ");

	}

}
