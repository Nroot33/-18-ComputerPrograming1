
public class Undergraduate extends Student {

	private String club;

	public Undergraduate(String name,String num,String major,int grade,int credit,String club) {
		super(name,num,major,grade,credit);
		this.club = club;
	}
	
	@Override
	public void print() {
		// TODO Auto-generated method stub
		super.print();
		System.out.println("club : " + club);
	}

	public String getClub() {
		return club;
	}

	public void setClub(String club) {
		this.club = club;
	}
}
