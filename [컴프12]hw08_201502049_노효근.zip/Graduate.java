
public class Graduate extends Student{
	private String type;
	private double rate;
	
	public Graduate(String name,String num,String major,int grade,int credit,String type,double rate) {
		super(name,num,major,grade,credit);
		this.type = type;
		this.rate = rate;
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		super.print();
		System.out.println("type : " + type);
		System.out.println("rate : " + rate);
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}
}
