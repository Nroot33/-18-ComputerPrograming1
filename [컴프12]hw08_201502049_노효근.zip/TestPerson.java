
public class TestPerson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person preson1 = new Person();
		Person preson2 = new Person("John","Daejeon","010-1234-5678");
		
		
		preson1.print();
		System.out.println(" ");
		preson2.print();
		System.out.println(" ");
		
		Customer customur1 = new Customer();
		Customer customur2 = new Customer("John","Daejeon","010-1234-5678");
		Customer customur3 = new Customer("John","Daejeon","010-1234-5678",1004,500);
		
		customur1.print();
		System.out.println(" ");
		customur2.print();
		System.out.println(" ");
		customur3.print();
		System.out.println(" ");

	}

}
