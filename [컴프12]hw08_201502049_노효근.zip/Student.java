
public class Student {
	private String name;
	private String num;
	private String major;
	private int grade;
	private int credit;

	public Student() {

	}

	public Student(String name,String num,String major,int grade,int credit) {
		this.name = name;
		this.num = num;
		this.major = major;
		this.credit = credit;
		this.grade = grade;
	}
	
	public void print() {
		System.out.println("name : " + name);
		System.out.println("num : " + num);
		System.out.println("major : " + major);
		System.out.println("credit : " + credit);
		System.out.println("grade : " + grade);
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public int getCredit() {
		return credit;
	}

	public void setCredit(int credit) {
		this.credit = credit;
	}

}
