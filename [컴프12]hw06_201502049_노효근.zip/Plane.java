
public class Plane {

	private String company;
	private String model;
	private int passenger;
	private static int planes = 0;

	public Plane(String c, String m, int p) {
		company = c;
		model = m;
		passenger = p;
		planes++;
	}

	public Plane(String c, String m) {
		company = c;
		model = m;
		planes++;
	}

	public Plane(String c, int p) {
		company = c;
		passenger = p;
		planes++;
	}

	public static int getPlanes() {
		return planes;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getPassenger() {
		return passenger;
	}

	public void setPassenger(int passenger) {
		this.passenger = passenger;
	}

}
