
public class PlaneTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		Plane p1 = new Plane("KoreanAir","707",100);
		Plane p2 = new Plane("AsianAir","084");
		Plane p3 = new Plane("AmericanAir",300);
		
		int n = Plane.getPlanes();
		System.out.println("Present Planes : " + n);

	}

}
