
public class DogTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Dog dog1 = new Dog("puppy",5);
		
		dog1.print();
		
		Dog dog2 = new Dog("puppy","Yorkshire Terrier",5);
		
		dog2.print();

	}

}
