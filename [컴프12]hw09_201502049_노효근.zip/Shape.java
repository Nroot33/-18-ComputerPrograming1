public class Shape {
	int width, height;

	public Shape(int width, int height) {
		this.width = width;
		this.height = height;
	}

	
	public int Area() {
		return 0;
	}

}

class Rectangle extends Shape {
	
	public Rectangle(int width, int height) {
		super(width, height);
	
	}

	@Override
	public int Area() {
		return width * height;
	}
}

class Triangle extends Shape {

	public Triangle(int width, int height) {
		super(width, height);
		
	}

	@Override
	public int Area() {
		return (width * height) / 2;
	}
}

class Circle extends Shape {
	
	public Circle(int width, int height) {
		super(width, height);
	}

	public int Area() {
		return (int)(width*height*Math.PI);
	}
}
