
public class Testshape {
	private static Shape arrayOfShapes[];

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		arrayOfShapes = new Shape[3];
		arrayOfShapes[0] = new Rectangle(3,4);
		arrayOfShapes[1] = new Triangle(4,5);
		arrayOfShapes[2] = new Circle(6,6);

		for (int i = 0; i < arrayOfShapes.length; i++) {
			System.out.println("������ ���� : " + arrayOfShapes[i].Area());
		}
	}
}
